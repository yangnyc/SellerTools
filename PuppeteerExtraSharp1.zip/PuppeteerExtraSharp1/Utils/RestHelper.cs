﻿using RestSharp;
using System.Collections.Generic;

namespace PuppeteerExtraSharp.Utils
{
    public static class RestHelper
    {
        public static RestRequest AddQueryParameters(this RestRequest request, Dictionary<string, string> parameters)
        {
            foreach (var parameter in parameters)
            {
                request.AddQueryParameter(parameter.Key, parameter.Value);
            }

            return request;
        }
    }
}
