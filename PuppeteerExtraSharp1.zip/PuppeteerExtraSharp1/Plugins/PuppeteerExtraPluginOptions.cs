﻿namespace PuppeteerExtraSharp.Plugins
{
    public interface IPuppeteerExtraPluginOptions
    {
    }
}
