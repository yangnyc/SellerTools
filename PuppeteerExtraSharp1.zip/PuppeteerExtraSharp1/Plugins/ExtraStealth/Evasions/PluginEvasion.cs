﻿using PuppeteerSharp;
using System.Threading.Tasks;

namespace PuppeteerExtraSharp.Plugins.ExtraStealth.Evasions
{
    internal class PluginEvasion : PuppeteerExtraPlugin
    {
        public PluginEvasion() : base("stealth-pluginEvasion")
        {
        }

        public override async Task OnPageCreated(Page page)
        {
            var scipt = Utils.GetScript("Plugin.js");
            await Utils.EvaluateOnNewPage(page, scipt);
        }
    }
}