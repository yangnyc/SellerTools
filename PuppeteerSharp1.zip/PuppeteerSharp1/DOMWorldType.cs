using Newtonsoft.Json;
using PuppeteerSharp.Helpers.Json;
using System.Runtime.Serialization;

namespace PuppeteerSharp
{
    [JsonConverter(typeof(FlexibleStringEnumConverter), Other)]
    internal enum DOMWorldType
    {
        Other,
        [EnumMember(Value = "isolated")]
        Isolated,
        [EnumMember(Value = "default")]
        Default
    }
}