namespace PuppeteerSharp.Input
{
    internal class TouchPoint
    {
        public decimal X { get; set; }

        public decimal Y { get; set; }
    }
}
