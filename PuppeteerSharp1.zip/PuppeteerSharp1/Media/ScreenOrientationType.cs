namespace PuppeteerSharp.Media
{
    internal class ScreenOrientationType
    {
        internal static string LandscapePrimary => "landscapePrimary";

        internal static string PortraitPrimary => "portraitPrimary";
    }
}
