namespace PuppeteerSharp.Media
{
    internal class ScreenOrientation
    {
        public int Angle { get; internal set; }

        public string Type { get; internal set; }
    }
}
