﻿namespace PuppeteerSharp
{
    internal class SessionAttachedEventArgs
    {
        public CDPSession Session { get; set; }
    }
}