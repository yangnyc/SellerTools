namespace PuppeteerSharp.Messaging
{
    internal class StackTrace
    {
        public ConsoleMessageLocation[] CallFrames { get; set; }
    }
}
