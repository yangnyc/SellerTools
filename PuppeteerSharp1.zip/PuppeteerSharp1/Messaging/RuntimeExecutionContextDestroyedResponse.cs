namespace PuppeteerSharp.Messaging
{
    internal class RuntimeExecutionContextDestroyedResponse
    {
        public int ExecutionContextId { get; set; }
    }
}
