using System.Collections.Generic;

namespace PuppeteerSharp.Messaging
{
    internal class PerformanceGetMetricsResponse
    {
        public List<Metric> Metrics { get; set; }
    }
}
