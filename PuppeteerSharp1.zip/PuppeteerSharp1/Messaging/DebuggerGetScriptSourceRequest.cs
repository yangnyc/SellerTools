namespace PuppeteerSharp.Messaging
{
    internal class DebuggerGetScriptSourceRequest
    {
        public string ScriptId { get; set; }
    }
}
