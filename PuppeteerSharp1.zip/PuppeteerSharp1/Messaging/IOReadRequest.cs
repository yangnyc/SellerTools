namespace PuppeteerSharp.Messaging
{
    internal class IOReadRequest
    {
        public string Handle { get; set; }
    }
}
