namespace PuppeteerSharp.Messaging
{
    internal class LifecycleEventResponse
    {
        public string FrameId { get; set; }

        public string LoaderId { get; set; }

        public string Name { get; set; }
    }
}
