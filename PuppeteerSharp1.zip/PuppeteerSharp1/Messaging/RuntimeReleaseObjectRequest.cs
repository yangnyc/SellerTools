namespace PuppeteerSharp.Messaging
{
    internal class RuntimeReleaseObjectRequest
    {
        public string ObjectId { get; set; }
    }
}
