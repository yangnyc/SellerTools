namespace PuppeteerSharp.Messaging
{
    internal class TargetDetachFromTargetRequest
    {
        public string SessionId { get; set; }
    }
}
