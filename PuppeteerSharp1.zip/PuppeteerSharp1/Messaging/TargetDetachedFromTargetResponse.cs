namespace PuppeteerSharp.Messaging
{
    internal class TargetDetachedFromTargetResponse
    {
        public string SessionId { get; set; }
    }
}
