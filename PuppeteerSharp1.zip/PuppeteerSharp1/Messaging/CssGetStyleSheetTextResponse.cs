namespace PuppeteerSharp.Messaging
{
    internal class CssGetStyleSheetTextResponse
    {
        public string Text { get; set; }
    }
}
