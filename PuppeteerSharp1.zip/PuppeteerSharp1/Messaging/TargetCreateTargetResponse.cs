namespace PuppeteerSharp.Messaging
{
    internal class TargetCreateTargetResponse
    {
        public string TargetId { get; set; }
    }
}
