namespace PuppeteerSharp.Messaging
{
    internal class RuntimeAddBindingRequest
    {
        public string Name { get; set; }
    }
}
