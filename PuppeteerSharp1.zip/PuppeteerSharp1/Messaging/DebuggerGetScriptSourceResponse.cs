namespace PuppeteerSharp.Messaging
{
    internal class DebuggerGetScriptSourceResponse
    {
        public string ScriptSource { get; set; }
    }
}
