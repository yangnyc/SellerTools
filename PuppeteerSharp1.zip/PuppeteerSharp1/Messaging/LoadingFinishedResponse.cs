namespace PuppeteerSharp.Messaging
{
    internal class LoadingFinishedResponse
    {
        public string RequestId { get; set; }
    }
}
