namespace PuppeteerSharp.Messaging
{
    internal class SecurityHandleCertificateErrorResponse
    {
        public int EventId { get; set; }

        public string Action { get; set; }
    }
}
