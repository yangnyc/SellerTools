namespace PuppeteerSharp.Messaging
{
    internal class PageNavigateResponse
    {
        public string ErrorText { get; set; }

        public string LoaderId { get; set; }
    }
}
