namespace PuppeteerSharp.Messaging
{
    internal class BrowserResetPermissionsRequest
    {
        public string BrowserContextId { get; set; }
    }
}
