namespace PuppeteerSharp.Messaging
{
    internal class PageSetInterceptFileChooserDialog
    {
        public bool Enabled { get; set; }
    }
}
