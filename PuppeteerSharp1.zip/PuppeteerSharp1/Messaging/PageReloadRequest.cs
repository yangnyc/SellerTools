namespace PuppeteerSharp.Messaging
{
    internal class PageReloadRequest
    {
        public string FrameId { get; set; }
    }
}
