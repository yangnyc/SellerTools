namespace PuppeteerSharp.Messaging
{
    internal class PageFrameNavigatedResponse
    {
        public FramePayload Frame { get; set; }
    }
}
