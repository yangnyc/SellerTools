namespace PuppeteerSharp.Messaging
{
    internal class TargetAttachToTargetResponse
    {
        public string SessionId { get; set; }
    }
}