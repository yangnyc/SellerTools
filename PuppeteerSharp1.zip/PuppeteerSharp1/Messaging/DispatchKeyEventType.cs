using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Runtime.Serialization;

namespace PuppeteerSharp.Messaging
{
    [JsonConverter(typeof(StringEnumConverter))]
    internal enum DispatchKeyEventType
    {
        [EnumMember(Value = "keyDown")]
        KeyDown,
        [EnumMember(Value = "rawKeyDown")]
        RawKeyDown,
        [EnumMember(Value = "keyUp")]
        KeyUp,
    }
}