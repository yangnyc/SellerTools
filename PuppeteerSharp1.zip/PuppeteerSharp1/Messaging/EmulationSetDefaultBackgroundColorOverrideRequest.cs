namespace PuppeteerSharp.Messaging
{
    internal class EmulationSetDefaultBackgroundColorOverrideRequest
    {
        public EmulationSetDefaultBackgroundColorOverrideColor Color { get; set; }
    }
}
