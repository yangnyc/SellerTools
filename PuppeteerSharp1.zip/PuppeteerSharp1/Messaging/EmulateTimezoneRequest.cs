namespace PuppeteerSharp.Messaging
{
    internal class EmulateTimezoneRequest
    {
        public string TimezoneId { get; set; }
    }
}
