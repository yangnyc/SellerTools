namespace PuppeteerSharp.Messaging
{
    internal class DebuggerSetSkipAllPausesRequest
    {
        public bool Skip { get; set; }
    }
}
