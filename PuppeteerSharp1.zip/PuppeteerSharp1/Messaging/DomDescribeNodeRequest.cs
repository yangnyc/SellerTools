namespace PuppeteerSharp.Messaging
{
    internal class DomDescribeNodeRequest
    {
        public string ObjectId { get; set; }
    }
}
