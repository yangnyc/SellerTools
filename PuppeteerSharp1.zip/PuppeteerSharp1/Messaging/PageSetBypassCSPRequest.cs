namespace PuppeteerSharp.Messaging
{
    internal class PageSetBypassCSPRequest
    {
        public bool Enabled { get; set; }
    }
}
