namespace PuppeteerSharp.Messaging
{
    internal class GetBrowserContextsResponse
    {
        public string[] BrowserContextIds { get; set; }
    }
}
