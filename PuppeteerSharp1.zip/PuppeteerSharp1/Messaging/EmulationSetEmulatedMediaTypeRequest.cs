using PuppeteerSharp.Media;

namespace PuppeteerSharp.Messaging
{
    internal class EmulationSetEmulatedMediaTypeRequest
    {
        public MediaType Media { get; set; }
    }
}
