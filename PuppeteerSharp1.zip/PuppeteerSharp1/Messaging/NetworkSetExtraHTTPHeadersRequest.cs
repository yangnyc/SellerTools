using System.Collections.Generic;

namespace PuppeteerSharp.Messaging
{
    internal class NetworkSetExtraHTTPHeadersRequest
    {
        public Dictionary<string, string> Headers { get; set; }
    }
}
