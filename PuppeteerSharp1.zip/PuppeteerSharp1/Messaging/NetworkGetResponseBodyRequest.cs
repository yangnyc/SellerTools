namespace PuppeteerSharp.Messaging
{
    internal class NetworkGetResponseBodyRequest
    {
        public string RequestId { get; set; }
    }
}
