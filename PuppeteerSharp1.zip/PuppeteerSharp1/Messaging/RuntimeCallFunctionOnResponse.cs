namespace PuppeteerSharp.Messaging
{
    internal class RuntimeCallFunctionOnResponse
    {
        public RemoteObject Result { get; set; }
    }
}
