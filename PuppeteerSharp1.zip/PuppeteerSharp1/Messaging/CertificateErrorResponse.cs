namespace PuppeteerSharp.Messaging
{
    internal class CertificateErrorResponse
    {
        public int EventId { get; set; }
    }
}