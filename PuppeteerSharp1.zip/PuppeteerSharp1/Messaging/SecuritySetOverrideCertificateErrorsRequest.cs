namespace PuppeteerSharp.Messaging
{
    internal class SecuritySetOverrideCertificateErrorsRequest
    {
        public bool Override { get; set; }
    }
}
