namespace PuppeteerSharp.Messaging
{
    internal class TargetActivateTargetRequest
    {
        public string TargetId { get; set; }
    }
}
