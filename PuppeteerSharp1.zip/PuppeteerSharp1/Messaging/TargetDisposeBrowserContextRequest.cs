namespace PuppeteerSharp.Messaging
{
    internal class TargetDisposeBrowserContextRequest
    {
        public string BrowserContextId { get; set; }
    }
}
