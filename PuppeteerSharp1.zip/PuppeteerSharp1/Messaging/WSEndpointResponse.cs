namespace PuppeteerSharp.Messaging
{
    internal class WSEndpointResponse
    {
        public string WebSocketDebuggerUrl { get; set; }
    }
}
