namespace PuppeteerSharp.Messaging
{
    internal class IOCloseRequest
    {
        public string Handle { get; set; }
    }
}
