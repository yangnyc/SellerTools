namespace PuppeteerSharp.Messaging
{
    internal class TargetSendMessageToTargetRequest
    {
        public string SessionId { get; set; }

        public string Message { get; set; }
    }
}
