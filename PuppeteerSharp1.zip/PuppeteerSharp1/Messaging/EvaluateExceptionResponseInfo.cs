namespace PuppeteerSharp
{
    internal class EvaluateExceptionResponseInfo
    {
        public string Description { get; set; }

        public string Value { get; set; }
    }
}
