namespace PuppeteerSharp.Messaging
{
    internal class PageSetLifecycleEventsEnabledRequest
    {
        public bool Enabled { get; internal set; }
    }
}
