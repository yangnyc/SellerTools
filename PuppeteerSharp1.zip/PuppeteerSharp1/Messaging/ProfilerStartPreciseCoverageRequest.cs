namespace PuppeteerSharp.Messaging
{
    internal class ProfilerStartPreciseCoverageRequest
    {
        public bool CallCount { get; set; }

        public bool Detailed { get; set; }
    }
}
