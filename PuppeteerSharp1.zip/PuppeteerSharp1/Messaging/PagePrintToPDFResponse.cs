namespace PuppeteerSharp.Messaging
{
    internal class PagePrintToPDFResponse
    {
        public string Data { get; set; }

        public string Stream { get; set; }
    }
}
