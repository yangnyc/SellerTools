namespace PuppeteerSharp.Messaging
{
    internal class PageAddScriptToEvaluateOnNewDocumentRequest
    {
        public string Source { get; set; }

        public string WorldName { get; set; }
    }
}
