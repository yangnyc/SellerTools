namespace PuppeteerSharp.Messaging
{
    internal class EmulationSetScriptExecutionDisabledRequest
    {
        public bool Value { get; set; }
    }
}
