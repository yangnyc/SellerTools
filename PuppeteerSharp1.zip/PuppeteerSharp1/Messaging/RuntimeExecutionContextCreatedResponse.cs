namespace PuppeteerSharp.Messaging
{
    internal class RuntimeExecutionContextCreatedResponse
    {
        public ContextPayload Context { get; set; }
    }
}
