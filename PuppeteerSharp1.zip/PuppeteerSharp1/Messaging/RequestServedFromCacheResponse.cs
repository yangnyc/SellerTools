namespace PuppeteerSharp.Messaging
{
    internal class RequestServedFromCacheResponse
    {
        public string RequestId { get; set; }
    }
}
