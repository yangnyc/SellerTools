namespace PuppeteerSharp.Messaging
{
    internal class CreateBrowserContextResponse
    {
        public string BrowserContextId { get; set; }
    }
}
