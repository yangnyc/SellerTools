namespace PuppeteerSharp.Messaging
{
    internal class RuntimeQueryObjectsResponse
    {
        public RemoteObject Objects { get; set; }
    }
}
