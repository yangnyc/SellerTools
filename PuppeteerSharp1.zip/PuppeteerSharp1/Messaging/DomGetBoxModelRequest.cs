namespace PuppeteerSharp.Messaging
{
    internal class DomGetBoxModelRequest
    {
        public string ObjectId { get; internal set; }
    }
}
