namespace PuppeteerSharp.Messaging
{
    internal class InputInsertTextRequest
    {
        public string Text { get; set; }
    }
}
