namespace PuppeteerSharp.Messaging
{
    internal class DebuggerScriptParsedResponse
    {
        public string Url { get; set; }

        public string ScriptId { get; set; }
    }
}
