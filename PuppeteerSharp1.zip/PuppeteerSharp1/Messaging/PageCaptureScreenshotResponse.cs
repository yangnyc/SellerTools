namespace PuppeteerSharp.Messaging
{
    internal class PageCaptureScreenshotResponse
    {
        public string Data { get; set; }
    }
}
