namespace PuppeteerSharp.Messaging
{
    internal class DomResolveNodeResponse
    {
        public RemoteObject Object { get; set; }
    }
}
