namespace PuppeteerSharp.Messaging
{
    internal class RuntimeExceptionThrownResponse
    {
        public EvaluateExceptionResponseDetails ExceptionDetails { get; set; }
    }
}
