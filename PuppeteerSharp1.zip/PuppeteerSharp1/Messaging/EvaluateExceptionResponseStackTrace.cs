namespace PuppeteerSharp
{
    internal class EvaluateExceptionResponseStackTrace
    {
        public EvaluationExceptionResponseCallFrame[] CallFrames { get; set; }
    }
}