namespace PuppeteerSharp.Messaging
{
    internal class CssGetStyleSheetTextRequest
    {
        public string StyleSheetId { get; set; }
    }
}
