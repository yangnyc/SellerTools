namespace PuppeteerSharp.Messaging
{
    internal class PageNavigateToHistoryEntryRequest
    {
        public int EntryId { get; internal set; }
    }
}
