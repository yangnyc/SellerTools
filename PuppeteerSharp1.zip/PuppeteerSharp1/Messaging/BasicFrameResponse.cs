namespace PuppeteerSharp.Messaging
{
    internal class BasicFrameResponse
    {
        public string FrameId { get; set; }
    }
}