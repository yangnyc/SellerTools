namespace PuppeteerSharp.Messaging
{
    internal class NetworkSetCacheDisabledRequest
    {
        public bool CacheDisabled { get; set; }
    }
}
