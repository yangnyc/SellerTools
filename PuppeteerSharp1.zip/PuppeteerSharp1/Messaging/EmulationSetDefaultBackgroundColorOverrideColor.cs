namespace PuppeteerSharp.Messaging
{
    internal class EmulationSetDefaultBackgroundColorOverrideColor
    {
        public int R { get; set; }

        public int B { get; set; }

        public int A { get; set; }

        public int G { get; set; }
    }
}
