namespace PuppeteerSharp.Messaging
{
    internal class TargetCloseTargetRequest
    {
        public string TargetId { get; set; }
    }
}
