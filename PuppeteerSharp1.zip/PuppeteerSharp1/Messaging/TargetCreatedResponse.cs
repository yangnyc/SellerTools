namespace PuppeteerSharp.Messaging
{
    internal class TargetCreatedResponse
    {
        public TargetInfo TargetInfo { get; set; }
    }
}