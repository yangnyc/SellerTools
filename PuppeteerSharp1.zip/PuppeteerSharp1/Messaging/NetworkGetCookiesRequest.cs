namespace PuppeteerSharp.Messaging
{
    internal class NetworkGetCookiesRequest
    {
        public string[] Urls { get; set; }
    }
}
