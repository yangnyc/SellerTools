namespace PuppeteerSharp.Messaging
{
    internal class GetContentQuadsResponse
    {
        public decimal[][] Quads { get; set; }
    }
}