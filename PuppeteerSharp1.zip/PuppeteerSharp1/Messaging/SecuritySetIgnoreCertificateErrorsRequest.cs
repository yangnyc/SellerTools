namespace PuppeteerSharp.Messaging
{
    internal class SecuritySetIgnoreCertificateErrorsRequest
    {
        public bool Ignore { get; set; }
    }
}
