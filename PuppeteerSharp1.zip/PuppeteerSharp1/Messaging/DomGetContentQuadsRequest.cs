namespace PuppeteerSharp.Messaging
{
    internal class DomGetContentQuadsRequest
    {
        public string ObjectId { get; set; }
    }
}
