namespace PuppeteerSharp.Messaging
{
    internal class RuntimeQueryObjectsRequest
    {
        public string PrototypeObjectId { get; set; }
    }
}
