namespace PuppeteerSharp.Messaging
{
    internal class NetworkGetResponseBodyResponse
    {
        public string Body { get; set; }

        public bool Base64Encoded { get; set; }
    }
}
