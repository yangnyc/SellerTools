namespace PuppeteerSharp.Messaging
{
    internal class TracingCompleteResponse
    {
        public string Stream { get; set; }
    }
}
