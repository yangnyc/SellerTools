namespace PuppeteerSharp.Messaging
{
    internal class Header
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
