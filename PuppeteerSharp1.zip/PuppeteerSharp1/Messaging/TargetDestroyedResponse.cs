namespace PuppeteerSharp.Messaging
{
    internal class TargetDestroyedResponse
    {
        public string TargetId { get; set; }
    }
}