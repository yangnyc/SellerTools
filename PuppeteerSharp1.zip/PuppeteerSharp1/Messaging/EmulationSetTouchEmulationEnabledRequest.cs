namespace PuppeteerSharp.Messaging
{
    internal class EmulationSetTouchEmulationEnabledRequest
    {
        public string Configuration { get; set; }

        public bool Enabled { get; set; }
    }
}
