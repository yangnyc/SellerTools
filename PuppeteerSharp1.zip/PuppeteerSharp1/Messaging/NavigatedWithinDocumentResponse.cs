namespace PuppeteerSharp.Messaging
{
    internal class NavigatedWithinDocumentResponse
    {
        public string FrameId { get; set; }

        public string Url { get; set; }
    }
}
