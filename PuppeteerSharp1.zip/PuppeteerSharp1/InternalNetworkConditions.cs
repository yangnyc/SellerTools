namespace PuppeteerSharp
{
    internal class InternalNetworkConditions : NetworkConditions
    {
        public bool Offline { get; set; }
    }
}
