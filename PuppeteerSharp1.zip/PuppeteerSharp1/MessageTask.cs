using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace PuppeteerSharp
{
    internal class MessageTask
    {
        internal MessageTask()
        {
        }

        #region public Properties
        internal TaskCompletionSource<JObject> TaskWrapper { get; set; }

        internal string Method { get; set; }
        #endregion
    }
}
